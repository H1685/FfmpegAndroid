# Custom FFmpeg Build for Modern Android Phones

This is a custom FFmpeg build optimized for PNG overlay capabilities on modern Android phones (Samsung, Xiaomi, etc.).

## Features

- PNG overlay support
- Minimal build with only required components
- Optimized for arm64-v8a architecture used in modern Android devices

## Usage

1. Copy the `.so` files from the arm64-v8a folder to your Android project's `jniLibs/arm64-v8a` directory
2. Include the headers for NDK development

## Supported Devices

This build targets modern Android phones including:
- Samsung Galaxy (S and Note series from 2016 onwards)
- Xiaomi (Mi, Redmi, POCO series)
- OnePlus 
- Other devices using 64-bit ARM processors
